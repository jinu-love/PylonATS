package com.jinus.isetdx.happyfriday.overtime.service.post;

import lombok.Data;

@Data
public class PostOut {
	private boolean success = true;
}
