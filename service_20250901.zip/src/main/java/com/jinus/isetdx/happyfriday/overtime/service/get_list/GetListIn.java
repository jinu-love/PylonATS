package com.jinus.isetdx.happyfriday.overtime.service.get_list;

import lombok.Data;



@Data
public class GetListIn {
	private String email;
}
