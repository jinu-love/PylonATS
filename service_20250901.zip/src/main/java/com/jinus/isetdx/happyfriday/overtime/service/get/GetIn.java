package com.jinus.isetdx.happyfriday.overtime.service.get;

import lombok.Data;

@Data
public class GetIn {
	private String email;
	private String date;
}
