package com.jinus.isetdx.happyfriday.overtime.service.get_list;

import java.util.List;

import com.jinus.isetdx.happyfriday.overtime.service.get.GetOut;

import lombok.Data;

@Data
public class GetListOut {
	private boolean success = true;
	private List<GetOut> overtimeList;
}
