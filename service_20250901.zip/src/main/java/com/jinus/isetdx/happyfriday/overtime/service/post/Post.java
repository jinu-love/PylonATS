package com.jinus.isetdx.happyfriday.overtime.service.post;

public class Post {
	public PostOut post(PostIn input) throws Exception {

		PostOut output = new PostOut();
		output.setSuccess(true);
		return output;
	}
}
