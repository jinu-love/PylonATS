package com.jinus.isetdx.happyfriday.overtime.service.post;

import lombok.Data;

@Data
public class PostIn {
	private String email;
	private String overtimeDate;
	private String overtimeHours;
	private String comment;
}
