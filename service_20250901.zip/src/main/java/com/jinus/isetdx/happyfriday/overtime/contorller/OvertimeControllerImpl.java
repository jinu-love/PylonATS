package com.jinus.isetdx.happyfriday.overtime.contorller;

import com.jinus.framework.util.BeanUtils;
import com.jinus.isetdx.happyfriday.overtime.service.get.Get;
import com.jinus.isetdx.happyfriday.overtime.service.get.GetIn;
import com.jinus.isetdx.happyfriday.overtime.service.get.GetOut;
import com.jinus.isetdx.happyfriday.overtime.service.get_list.GetList;
import com.jinus.isetdx.happyfriday.overtime.service.get_list.GetListIn;
import com.jinus.isetdx.happyfriday.overtime.service.get_list.GetListOut;
import com.jinus.isetdx.happyfriday.overtime.service.post.Post;
import com.jinus.isetdx.happyfriday.overtime.service.post.PostIn;
import com.jinus.isetdx.happyfriday.overtime.service.post.PostOut;

public class OvertimeControllerImpl implements OvertimeController {

	@Override
	public GetOut get(GetIn input) throws Exception {
		return BeanUtils.get(Get.class).get(input);
	}

	@Override
	public GetListOut getList(GetListIn input) throws Exception {
		return BeanUtils.get(GetList.class).getList(input);
	}

	@Override
	public PostOut post(PostIn input) throws Exception {
		return BeanUtils.get(Post.class).post(input);
	}

}
