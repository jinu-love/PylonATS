package com.jinus.isetdx.happyfriday.model;

public class overtimeInf {

}
