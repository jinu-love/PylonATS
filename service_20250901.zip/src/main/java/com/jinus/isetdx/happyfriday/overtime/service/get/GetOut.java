package com.jinus.isetdx.happyfriday.overtime.service.get;

import lombok.Data;

@Data
public class GetOut {
	private boolean success = true;
	private String email;
	private String overtimeDate;
	private String overtimeHours;
}
