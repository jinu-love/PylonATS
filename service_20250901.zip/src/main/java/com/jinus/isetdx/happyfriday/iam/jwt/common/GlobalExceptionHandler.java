package com.jinus.isetdx.happyfriday.iam.jwt.common;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	
	// 중복 리소스(이메일 등) -> 409 Conflict
	@ExceptionHandler(DuplicateResourceException.class)
	public ResponseEntity<ApiError> handleDuplicate(DuplicateResourceException e) {
		return ResponseEntity.status(HttpStatus.CONFLICT).body(new ApiError(e.getMessage(), null));
	}

	// 중복 리소스(이메일 등) -> 409 Conflict
	@ExceptionHandler(DuplicateEmailException.class)
	public ResponseEntity<Map<String, Object>> handleDuplicateEmail(DuplicateEmailException ex) {
        Map<String, Object> body = Map.of(
            "code", "EMAIL_ALREADY_EXISTS",
            "message", ex.getMessage(),
            "fields", Map.of("email", ex.getMessage())
        );
        return ResponseEntity.status(HttpStatus.CONFLICT).body(body); // 409
    }
	
	@ExceptionHandler(org.springframework.dao.DataIntegrityViolationException.class)
    public ResponseEntity<Map<String, Object>> handleDataIntegrity(org.springframework.dao.DataIntegrityViolationException ex) {
        Map<String, Object> body = Map.of(
            "code", "UNIQUE_CONSTRAINT_VIOLATION",
            "message", "이미 등록된 이메일입니다.",
            "fields", Map.of("email", "이미 등록된 이메일입니다.")
        );
        return ResponseEntity.status(HttpStatus.CONFLICT).body(body); // 409
    }


	// 검증 실패 -> 400 Bad Request (필드별 에러 포함)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ApiError> handleValidation(MethodArgumentNotValidException e) {
		
		List<ApiError.FieldError> fields = e.getBindingResult().getFieldErrors().stream()
				.map(err -> new ApiError.FieldError(err.getField(), err.getDefaultMessage())).toList();
		
//		
//		String a = e.getMessage();
//		String b = e.getBindingResult().getFieldErrors().stream()
//		.map(err -> new ApiError.FieldError(err.getField(), err.getDefaultMessage()));
//		
//		

		
	
		

		return ResponseEntity.badRequest().body(new ApiError(fields.getFirst().message(), fields));
		//return ResponseEntity.badRequest().body(new ApiError(e.getMessage(), null));
	}
//	@ExceptionHandler(MethodArgumentNotValidException.class)
//	public Map<String, String> handleValidationErrors(MethodArgumentNotValidException ex) {
//		Map<String, String> errors = new java.util.HashMap<>();
//		ex.getBindingResult().getFieldErrors().forEach(err -> {
//			errors.put(err.getField(), err.getDefaultMessage());
//		});
//		return errors;
//	}

	// 그 외 예외 -> 500
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ApiError> handleOther(Exception e) {
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ApiError("서버 오류가 발생했습니다.", null));
	}
}