package com.jinus.isetdx.happyfriday.overtime.contorller;

import org.springdoc.core.annotations.ParameterObject;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jinus.isetdx.happyfriday.overtime.service.get.GetIn;
import com.jinus.isetdx.happyfriday.overtime.service.get.GetOut;
import com.jinus.isetdx.happyfriday.overtime.service.get_list.GetListIn;
import com.jinus.isetdx.happyfriday.overtime.service.get_list.GetListOut;
import com.jinus.isetdx.happyfriday.overtime.service.post.PostIn;
import com.jinus.isetdx.happyfriday.overtime.service.post.PostOut;

@RequestMapping(path = "/v1")
public interface OvertimeController {

	static final String RESOURCE = "/overtime";

	@GetMapping("/get")
	GetOut get(@ParameterObject GetIn input) throws Exception;

	@GetMapping("/get/list")
	GetListOut getList(@ParameterObject GetListIn input) throws Exception;

	@PostMapping("/post")
	PostOut post(@RequestBody PostIn input) throws Exception;

}
