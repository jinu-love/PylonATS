package com.jinus.isetdx.happyfriday.overtime.contorller;

import org.springdoc.core.annotations.ParameterObject;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jinus.isetdx.happyfriday.overtime.service.get_overtime_history.GetOvertimeHistoryIn;
import com.jinus.isetdx.happyfriday.overtime.service.get_overtime_history.GetOvertimeHistoryOut;
import com.jinus.isetdx.happyfriday.overtime.service.get_this_month_overtime.GetThisMonthOvertimeIn;
import com.jinus.isetdx.happyfriday.overtime.service.get_this_month_overtime.GetThisMonthOvertimeOut;
import com.jinus.isetdx.happyfriday.overtime.service.save_overtime.SaveOvertimeIn;
import com.jinus.isetdx.happyfriday.overtime.service.save_overtime.SaveOvertimeOut;

@RequestMapping(path = "/v1")
public interface OvertimeController {

	// static final String RESOURCE = "/overtime";
	@GetMapping("/get/overtime/history")
	GetOvertimeHistoryOut getOvertimeHistory(@ParameterObject GetOvertimeHistoryIn input) throws Exception;
	
	@GetMapping("/get/this/month/overtime")
	GetThisMonthOvertimeOut getThisMonthOvertime(@ParameterObject GetThisMonthOvertimeIn input) throws Exception;

	@PostMapping("/save/overtime")
	SaveOvertimeOut saveOvertime(@RequestBody SaveOvertimeIn input) throws Exception;

}
