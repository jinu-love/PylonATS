package com.jinus.isetdx.happyfriday.overtime.service.save_overtime;

import java.time.DayOfWeek;
import java.time.ZonedDateTime;

import com.jinus.framework.exception.BizException;
import com.jinus.framework.util.DbUtils;
import com.jinus.framework.util.ValueUtils;
import com.jinus.isetdx.happyfriday.model.OvertimeInf;

public class SaveOvertime {

	public SaveOvertimeOut saveOvertime(SaveOvertimeIn input) throws Exception {

		ZonedDateTime date = ValueUtils.getZonedDateTime();

		DayOfWeek dayOfWeek = date.getDayOfWeek();

		int dayOfWeekNumber = dayOfWeek.getValue();

		if (dayOfWeekNumber >= 6) {
			throw new BizException("ERR-001", "주말에는 초과근무 시간을 등록할 수 없습니다.");
		}

		OvertimeInf overtimeInf = DbUtils.select(OvertimeInf.class,
				DbUtils.toId(input.getEmail(), input.getOvertimeDate()));

		if (ValueUtils.isEmpty(overtimeInf)) {
			overtimeInf = new OvertimeInf();
			overtimeInf.setEmail(input.getEmail());
			overtimeInf.setOvertimeDate(input.getOvertimeDate());
			overtimeInf.setCreatedDate(date);
		}

		overtimeInf.setOvertimeHours(input.getOvertimeHours());
		overtimeInf.setComment(input.getComment());
		overtimeInf.setUpdatedDate(date);
		DbUtils.upsert(overtimeInf);

		if (input.getOvertimeHours() == 0.0) {
			DbUtils.delete(overtimeInf);
		}

		SaveOvertimeOut output = new SaveOvertimeOut();
		output.setSuccess(true);
		return output;
	}

}
