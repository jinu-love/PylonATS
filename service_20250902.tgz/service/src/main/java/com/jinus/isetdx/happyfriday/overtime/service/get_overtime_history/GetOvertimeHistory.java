package com.jinus.isetdx.happyfriday.overtime.service.get_overtime_history;

import java.util.ArrayList;
import java.util.List;

import com.jinus.dbist.dml.Query;
import com.jinus.framework.util.DbUtils;
import com.jinus.framework.util.ValueUtils;
import com.jinus.isetdx.happyfriday.model.OvertimeInf;

public class GetOvertimeHistory {

	public GetOvertimeHistoryOut getOvertimeHistory(GetOvertimeHistoryIn input) throws Exception {

		Query query = new Query();
		query.addFilter("email", input.getEmail());
		query.addOrder("overtimeDate", false);

		List<OvertimeInf> overtimeInfList = DbUtils.selectList(OvertimeInf.class, query);

		List<GetOvertimeHistoryOutDetail> detailList = new ArrayList<GetOvertimeHistoryOutDetail>();
		for (OvertimeInf overtimeInf : overtimeInfList) {
			GetOvertimeHistoryOutDetail detail = new GetOvertimeHistoryOutDetail();
			ValueUtils.populate(overtimeInf, detail);
			detailList.add(detail);
		}

		GetOvertimeHistoryOut output = new GetOvertimeHistoryOut();
		output.setSuccess(true);
		output.setOvertimeList(detailList);
		return output;
	}

}
