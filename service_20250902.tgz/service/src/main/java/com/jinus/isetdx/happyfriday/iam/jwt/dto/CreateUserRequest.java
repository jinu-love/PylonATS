package com.jinus.isetdx.happyfriday.iam.jwt.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record CreateUserRequest(@NotBlank(message = "이메일을 입력하세요.") @Email(message = "이메일 형식이 올바르지 않습니다.") String email,
		@NotBlank(message = "비밀번호를 입력하세요.") @Size(min = 8, message = "비밀번호는 최소 8자입니다.") String password,
		@NotBlank(message = "이름을 입력하세요.") @Size(min = 2, max = 50) String name, String phone) {

}

//public record CreateUserRequest(String email, String password, String name, String phone) {
//
//}
