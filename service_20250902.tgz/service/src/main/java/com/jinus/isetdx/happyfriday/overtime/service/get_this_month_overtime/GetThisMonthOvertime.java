package com.jinus.isetdx.happyfriday.overtime.service.get_this_month_overtime;

import java.util.List;

import com.jinus.dbist.dml.Query;
import com.jinus.framework.util.DbUtils;
import com.jinus.framework.util.ValueUtils;
import com.jinus.isetdx.happyfriday.model.OvertimeInf;

public class GetThisMonthOvertime {
	
	
	public GetThisMonthOvertimeOut getThisMonthOvertime(GetThisMonthOvertimeIn input) throws Exception {
	
		double monthOvertime = 0.0;
		
		String thisYearMonth = ValueUtils.toDateStr(ValueUtils.getZonedDateTime(), "YYYYMM");
		String thisMonth = ValueUtils.toDateStr(ValueUtils.getZonedDateTime(), "MM");
		
		Query query = new Query();
		
		query.addFilter("email", input.getEmail());
		query.addFilter("overtimeDate", "like", thisYearMonth + "%");
		List<OvertimeInf> overtimeInfList = DbUtils.selectList(OvertimeInf.class, query);
		for (OvertimeInf overtimeInf : overtimeInfList) {
			monthOvertime += overtimeInf.getOvertimeHours();
		}
		
		GetThisMonthOvertimeOut output = new GetThisMonthOvertimeOut();
		output.setOvertime(ValueUtils.toString(monthOvertime).replace(".0", ""));
		output.setThisMonth(thisMonth);
		output.setSuccess(true);
		return output;
	}

}
