package com.jinus.isetdx.happyfriday.iam.jwt.service;

import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jinus.isetdx.happyfriday.iam.jwt.common.DuplicateResourceException;
import com.jinus.isetdx.happyfriday.iam.jwt.dto.CreateUserRequest;
import com.jinus.isetdx.happyfriday.iam.jwt.dto.UserResponse;
import com.jinus.isetdx.happyfriday.iam.jwt.entity.Authority;
import com.jinus.isetdx.happyfriday.iam.jwt.entity.User;
import com.jinus.isetdx.happyfriday.iam.jwt.repository.AuthorityRepository;
import com.jinus.isetdx.happyfriday.iam.jwt.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional
public class UserServiceImpl implements UserService {
	
	private final UserRepository userRepository;
	private final AuthorityRepository authorityRepository;
	private final PasswordEncoder passwordEncoder;

	@Override
	public UserResponse createUser(CreateUserRequest request) {
		
		// 이메일 중복 검사
		if (userRepository.existsByEmail(request.email())) {
			//throw new DuplicateEmailException("이미 등록된 이메일입니다."); // 409
			throw new DuplicateResourceException("이미 등록된 이메일입니다."); // 409
		}

		// ROLE_USER 확보(없으면 생성)
		Authority roleUser = authorityRepository.findById("ROLE_USER").orElseGet(() -> authorityRepository
				.save(Authority.builder().authorityName("ROLE_USER").description("일반 사용자 권한").build()));

		// 비밀번호 암호화
		String encodedPw = passwordEncoder.encode(request.password());

		// 사용자 저장
		User saved = userRepository.save(User.builder().email(request.email()).password(encodedPw).name(request.name())
				.phone(request.phone()).authorities(Set.of(roleUser)).build());

		return new UserResponse(saved.getId(), saved.getEmail(), saved.getName(), saved.getPhone(),
				saved.getAuthorities().stream().map(Authority::getAuthorityName).collect(Collectors.toSet()),
				null);
	}
}
