package com.jinus.isetdx.happyfriday.iam.jwt.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record CreateUserRequest(@NotBlank @Email String email, @NotBlank @Size(min = 8, max = 100) String password,
		@NotBlank @Size(min = 2, max = 50) String name, String phone) {

}

//public record CreateUserRequest(String email, String password, String name, String phone) {
//
//}
