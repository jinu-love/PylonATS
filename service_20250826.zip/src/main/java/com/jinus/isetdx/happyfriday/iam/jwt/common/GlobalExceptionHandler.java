package com.jinus.isetdx.happyfriday.iam.jwt.common;

import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

	// 중복 리소스(이메일 등) -> 409 Conflict
	@ExceptionHandler(DuplicateResourceException.class)
	public ResponseEntity<ApiError> handleDuplicate(DuplicateResourceException e) {
		return ResponseEntity.status(HttpStatus.CONFLICT).body(new ApiError(e.getMessage(), null));
	}

	// 검증 실패 -> 400 Bad Request (필드별 에러 포함)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ApiError> handleValidation(MethodArgumentNotValidException e) {
		List<ApiError.FieldError> fields = e.getBindingResult().getFieldErrors().stream()
				.map(err -> new ApiError.FieldError(err.getField(), err.getDefaultMessage())).toList();

		return ResponseEntity.badRequest().body(new ApiError("유효성 검증 실패", fields));
	}

	// 그 외 예외 -> 500
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ApiError> handleOther(Exception e) {
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ApiError("서버 오류가 발생했습니다.", null));
	}
}