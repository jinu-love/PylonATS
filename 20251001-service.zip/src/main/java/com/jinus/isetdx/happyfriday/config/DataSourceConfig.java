package com.jinus.isetdx.happyfriday.config;

import org.springframework.context.annotation.Configuration;

import com.jinus.dbist.config.AbstractDataSourceConfig;

@Configuration
public class DataSourceConfig extends AbstractDataSourceConfig{

}
