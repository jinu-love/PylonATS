package com.jinus.isetdx.happyfriday.iam.jwt.dto;

import java.time.LocalDateTime;
import java.util.Set;

public record UserResponse(Long id,
        String email,
        String name,
        String phone,
        Set<String> roles,
        String dept,
        String rank,
        LocalDateTime createdDate) {

}
