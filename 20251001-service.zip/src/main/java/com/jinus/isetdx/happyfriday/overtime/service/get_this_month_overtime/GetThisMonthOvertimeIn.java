package com.jinus.isetdx.happyfriday.overtime.service.get_this_month_overtime;

import lombok.Data;

@Data
public class GetThisMonthOvertimeIn {
	private String email;
}
