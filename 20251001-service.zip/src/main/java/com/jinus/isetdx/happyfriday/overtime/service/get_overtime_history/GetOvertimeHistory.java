package com.jinus.isetdx.happyfriday.overtime.service.get_overtime_history;

import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import com.jinus.dbist.dml.Query;
import com.jinus.framework.util.DbUtils;
import com.jinus.framework.util.ValueUtils;
import com.jinus.isetdx.happyfriday.model.DayOffInf;
import com.jinus.isetdx.happyfriday.model.OvertimeInf;

public class GetOvertimeHistory {

	public GetOvertimeHistoryOut getOvertimeHistory(GetOvertimeHistoryIn input) throws Exception {

		Query query = new Query();
		query.addFilter("email", input.getEmail());
		query.addOrder("overtimeDate", false);
		List<OvertimeInf> overtimeInfList = DbUtils.selectList(OvertimeInf.class, query);
		
		query = new Query();
		query.addFilter("email", input.getEmail());
		query.addOrder("dayOffDate", false);
		List<DayOffInf> dayOffInfList = DbUtils.selectList(DayOffInf.class, query);

		List<GetOvertimeHistoryOutDetail> detailList = new ArrayList<GetOvertimeHistoryOutDetail>();
		for (OvertimeInf overtimeInf : overtimeInfList) {
			GetOvertimeHistoryOutDetail detail = new GetOvertimeHistoryOutDetail();
			ValueUtils.populate(overtimeInf, detail);
			detailList.add(detail);
		}
		
		for (DayOffInf dayOffInf : dayOffInfList) {
			GetOvertimeHistoryOutDetail detail = new GetOvertimeHistoryOutDetail();
			detail.setOvertimeDate(dayOffInf.getDayOffDate());
			detail.setComment(dayOffInf.getComment());
			detail.setOvertimeHours("휴무");
			detailList.add(detail);
		}
		
		
		
		

		List<GetOvertimeHistoryOutDetail> sortDetailList = detailList.stream().sorted(Comparator.comparing(GetOvertimeHistoryOutDetail::getOvertimeDate).reversed())
				.collect(Collectors.toList());
		
		
		
		
		
		for (GetOvertimeHistoryOutDetail his : sortDetailList) {
			ZonedDateTime zonedDatetime = ValueUtils.toZonedDateTime(his.getOvertimeDate());
			
			String a = ValueUtils.toDateStr(zonedDatetime, "yyyy-M-dd(E)");
			//String  a = sdfWithDay.format(zonedDatetime);


			his.setOvertimeDate(a);
		}
		
		
		GetOvertimeHistoryOut output = new GetOvertimeHistoryOut();
		output.setSuccess(true);
		output.setOvertimeList(sortDetailList);
		return output;
	}

}
