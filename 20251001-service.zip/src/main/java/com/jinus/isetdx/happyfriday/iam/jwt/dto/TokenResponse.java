package com.jinus.isetdx.happyfriday.iam.jwt.dto;

import java.util.Set;

public record TokenResponse(String jwt, String type, String email, String name, String phone, Set<String> roles, String dept, String rank) {
	public static TokenResponse of(String jwt, String email, String name, String phone, Set<String> roles, String dept, String rank) {
		return new TokenResponse(jwt, "Bearer", email, name, phone, roles, dept, rank);
	}
}
