package com.jinus.isetdx.happyfriday.overtime.service.save_day_off;

import lombok.Data;

@Data
public class SaveDayOffOut {
	private boolean success = true;
}
