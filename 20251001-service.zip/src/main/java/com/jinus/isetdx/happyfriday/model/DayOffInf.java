package com.jinus.isetdx.happyfriday.model;

import java.time.ZonedDateTime;

import com.jinus.dbist.annotation.DbistPrimaryKey;

import lombok.Data;

@Data
public class DayOffInf {
	@DbistPrimaryKey
	private String email;
	@DbistPrimaryKey
	private String dayOffDate;
	private String comment;
	private ZonedDateTime createdDate;
	private ZonedDateTime updatedDate;
}
