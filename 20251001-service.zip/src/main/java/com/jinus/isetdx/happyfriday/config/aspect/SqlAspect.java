package com.jinus.isetdx.happyfriday.config.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;


@Aspect
@Component
public class SqlAspect extends com.jinus.dbist.aspect.SqlAspect{

}
