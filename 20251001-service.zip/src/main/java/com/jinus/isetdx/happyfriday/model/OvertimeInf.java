package com.jinus.isetdx.happyfriday.model;

import java.time.ZonedDateTime;

import com.jinus.dbist.annotation.DbistPrimaryKey;

import lombok.Data;

@Data
public class OvertimeInf {
	@DbistPrimaryKey
	private String email;
	@DbistPrimaryKey
	private String overtimeDate;
	private double overtimeHours;
	private String comment;
	private ZonedDateTime createdDate;
	private ZonedDateTime updatedDate;
}
