package com.jinus.isetdx.happyfriday.iam.jwt.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jinus.isetdx.happyfriday.iam.jwt.entity.Authority;

public interface  AuthorityRepository extends JpaRepository<Authority, String> {

}
