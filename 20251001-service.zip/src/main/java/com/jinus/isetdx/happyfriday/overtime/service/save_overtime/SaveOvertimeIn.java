package com.jinus.isetdx.happyfriday.overtime.service.save_overtime;

import lombok.Data;

@Data
public class SaveOvertimeIn {
	private String email;
	private String overtimeDate;
	private double overtimeHours;
	private String comment;
}
