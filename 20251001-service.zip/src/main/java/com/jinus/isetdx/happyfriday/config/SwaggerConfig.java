package com.jinus.isetdx.happyfriday.config;

import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;

@OpenAPIDefinition(
        info = @Info(title = "Couple App",
                description = "couple app api명세",
                version = "v1"))
@Configuration
public class SwaggerConfig {
	/*
	@Bean
	public GroupedOpenApi chatOpenApi() {
		String[] paths = {"/v1/**"};
		return GroupedOpenApi.builder().group("COUPLE API v1").pathsToMatch(paths).build();
	}
	*/
}
