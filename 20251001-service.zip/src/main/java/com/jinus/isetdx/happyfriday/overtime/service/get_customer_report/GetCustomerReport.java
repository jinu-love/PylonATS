package com.jinus.isetdx.happyfriday.overtime.service.get_customer_report;

public class GetCustomerReport {

	public GetCustomerReportOut getCustomerReport(GetCustomerReportIn input)
			throws Exception {

		GetCustomerReportOut output = new GetCustomerReportOut();
		output.setSuccess(true);
		return output;
	}

}
