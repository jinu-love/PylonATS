package com.jinus.isetdx.happyfriday.user.controller;

public class UserControllerImpl implements UserController {

}
