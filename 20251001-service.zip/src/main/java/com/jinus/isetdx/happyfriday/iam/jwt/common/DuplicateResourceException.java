package com.jinus.isetdx.happyfriday.iam.jwt.common;

public class DuplicateResourceException extends RuntimeException {
	public DuplicateResourceException(String message) {
		super(message);
	}
}
