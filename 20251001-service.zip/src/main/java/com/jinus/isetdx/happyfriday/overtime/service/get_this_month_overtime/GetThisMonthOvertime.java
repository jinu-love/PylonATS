package com.jinus.isetdx.happyfriday.overtime.service.get_this_month_overtime;

import java.time.ZonedDateTime;
import java.util.List;

import com.jinus.dbist.dml.Query;
import com.jinus.framework.util.DbUtils;
import com.jinus.framework.util.ValueUtils;
import com.jinus.isetdx.happyfriday.model.DayOffInf;
import com.jinus.isetdx.happyfriday.model.OvertimeInf;

public class GetThisMonthOvertime {
	
	
	public GetThisMonthOvertimeOut getThisMonthOvertime(GetThisMonthOvertimeIn input) throws Exception {
	
		double monthOvertime = 0.0;
		
		String thisYearMonth = ValueUtils.toDateStr(ValueUtils.getZonedDateTime(), "YYYYMM");
		String thisMonth = ValueUtils.toDateStr(ValueUtils.getZonedDateTime(), "MM");
		
		Query query = new Query();
		
		query.addFilter("email", input.getEmail());
		query.addFilter("overtimeDate", "like", thisYearMonth + "%");
		List<OvertimeInf> overtimeInfList = DbUtils.selectList(OvertimeInf.class, query);
		for (OvertimeInf overtimeInf : overtimeInfList) {
			monthOvertime += overtimeInf.getOvertimeHours();
		}
		
		String dayOffDate = "사용안함";
		query = new Query();
		query.addFilter("email", input.getEmail());
		query.addFilter("dayOffDate", "like", thisYearMonth + "%");
		query.setMaxResultSize(1);
		DayOffInf dayOffInf = DbUtils.select(DayOffInf.class, query);
		if(!ValueUtils.isEmpty(dayOffInf)) {
			ZonedDateTime zonedDatetime = ValueUtils.toZonedDateTime(dayOffInf.getDayOffDate());
			dayOffDate = ValueUtils.toDateStr(zonedDatetime, "yyyy-M-dd(E)");
		}
		
		GetThisMonthOvertimeOut output = new GetThisMonthOvertimeOut();
		output.setOvertime(ValueUtils.toString(monthOvertime).replace(".0", ""));
		output.setThisMonth(thisMonth);
		output.setDayOffDate(dayOffDate);
		output.setSuccess(true);
		return output;
	}

}
