package com.jinus.isetdx.happyfriday.iam.jwt.dto;


import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TokenDto {
    private String jwt;
    private String type;
    private String email;
    
    public TokenDto(String jwt) {
        this.jwt = jwt;
        this.type = "Bearer";
    }
}
