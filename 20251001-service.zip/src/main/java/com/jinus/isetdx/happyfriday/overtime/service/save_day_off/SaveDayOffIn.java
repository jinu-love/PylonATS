package com.jinus.isetdx.happyfriday.overtime.service.save_day_off;

import lombok.Data;

@Data
public class SaveDayOffIn {
	private String email;
	private String DayOffDate;
	private String comment;
}
