package com.jinus.isetdx.happyfriday.iam.jwt.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jinus.isetdx.happyfriday.iam.jwt.dto.CreateUserRequest;
import com.jinus.isetdx.happyfriday.iam.jwt.dto.UserResponse;
import com.jinus.isetdx.happyfriday.iam.jwt.service.UserService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {

	private final UserService userService;

	// 회원가입
	@PostMapping()
	public ResponseEntity<UserResponse> createUser(@Valid @RequestBody CreateUserRequest request) {
		UserResponse userResponse = userService.createUser(request);
		return ResponseEntity.ok(userResponse);
	}
}
