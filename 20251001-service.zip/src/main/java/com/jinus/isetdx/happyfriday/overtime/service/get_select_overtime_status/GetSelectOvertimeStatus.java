package com.jinus.isetdx.happyfriday.overtime.service.get_select_overtime_status;

import java.util.ArrayList;
import java.util.List;

import com.jinus.dbist.dml.Query;
import com.jinus.framework.exception.BizException;
import com.jinus.framework.util.DbUtils;
import com.jinus.framework.util.ValueUtils;

public class GetSelectOvertimeStatus {

	public GetSelectOvertimeStatusOut getSelectOvertimeStatus(GetSelectOvertimeStatusIn input) throws Exception {
		
		if(ValueUtils.isEmpty(input.getName())) {
			throw new BizException("ERR-005", "이름을 입력해주세요.");
		}

		List<OvertimeStatus> overtimeStatusList = new ArrayList<OvertimeStatus>();
		
		Query query = new Query();
		query.addFilter("name", input.getName());

		
		
		if (ValueUtils.equals("초과근무", input.getRadioValue())) {
			overtimeStatusList = DbUtils.selectList(DbUtils.toSqlPath(this.getClass(), "select_overtime_status.sql"),
					query, OvertimeStatus.class);
		} else {
			overtimeStatusList = DbUtils.selectList(DbUtils.toSqlPath(this.getClass(), "select_dayoff_status.sql"),
					query, OvertimeStatus.class);
		}
		

		GetSelectOvertimeStatusOut output = new GetSelectOvertimeStatusOut();
		output.setOvertimeStatusList(overtimeStatusList);
		output.setSuccess(true);
		return output;

	}

}
