package com.jinus.isetdx.happyfriday.iam.jwt.common;

import java.util.List;

public record ApiError(String message, List<FieldError> errors) {
	public record FieldError(String field, String message) {
	}
}
