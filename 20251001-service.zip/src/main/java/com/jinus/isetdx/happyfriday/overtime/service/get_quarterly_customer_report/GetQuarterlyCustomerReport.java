package com.jinus.isetdx.happyfriday.overtime.service.get_quarterly_customer_report;

public class GetQuarterlyCustomerReport {
	
	
	public GetQuarterlyCustomerReportOut getQuarterlyCustomerReport(GetQuarterlyCustomerReportIn input) throws Exception {
		
		
		GetQuarterlyCustomerReportOut output = new GetQuarterlyCustomerReportOut();
		output.setSuccess(true);
		return output;
	}

}
