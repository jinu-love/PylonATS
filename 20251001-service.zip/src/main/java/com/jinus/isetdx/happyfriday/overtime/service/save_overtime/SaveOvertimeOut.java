package com.jinus.isetdx.happyfriday.overtime.service.save_overtime;

import lombok.Data;

@Data
public class SaveOvertimeOut {
	private boolean success = true;
}
