package com.jinus.isetdx.happyfriday.iam.jwt.controller;

import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jinus.isetdx.happyfriday.iam.jwt.dto.LoginDto;
import com.jinus.isetdx.happyfriday.iam.jwt.dto.TokenResponse;
import com.jinus.isetdx.happyfriday.iam.jwt.entity.Authority;
import com.jinus.isetdx.happyfriday.iam.jwt.entity.User;
import com.jinus.isetdx.happyfriday.iam.jwt.repository.UserRepository;
import com.jinus.isetdx.happyfriday.iam.jwt.util.JwtUtil;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
public class AuthController {

	private final JwtUtil jwtUtil;
	private final AuthenticationManager authenticationManager;
	private final UserRepository userRepository;

	@PostMapping("/authenticate")
	public ResponseEntity<?> authenticate(@RequestBody @Valid LoginDto loginDto) {
		
		try {
			UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(
					loginDto.getEmail(), loginDto.getPassword());

			Authentication authentication = authenticationManager.authenticate(authenticationToken);

			String jwt = jwtUtil.createToken(authentication);
			
			// 3) 사용자 정보 조회
			User user = userRepository.findByEmail(loginDto.getEmail())
					.orElseThrow(() -> new IllegalStateException("인증은 성공했으나 사용자 정보를 찾을 수 없습니다."));
			
			Set<String> roles = user.getAuthorities().stream()
	                .map(Authority::getAuthorityName)
	                .collect(Collectors.toSet());
			
			// 4) 토큰 + 사용자 정보 함께 응답
	        TokenResponse body = TokenResponse.of(jwt, user.getEmail(), user.getName(), user.getPhone(), roles, user.getDept(), user.getRank());

	        return ResponseEntity.ok(body);

			//return ResponseEntity.ok(new TokenDto(jwt, "Bearer", loginDto.getEmail()));
		} catch (AuthenticationException e) {
			return ResponseEntity.status(401).body("인증에 실패했습니다.");
		}
	}

	@GetMapping("/user")
	public ResponseEntity<String> getMyUserInfo(Authentication authentication) {
		return ResponseEntity.ok("안녕하세요, " + authentication.getName() + "님!");
	}
}
