package com.jinus.isetdx.happyfriday.config.aspect;

import org.springframework.web.bind.annotation.ControllerAdvice;

import com.jinus.framework.exception.handler.MessageExceptionHandler;



//@ControllerAdvice
public class ExceptionHandler extends MessageExceptionHandler {

}
