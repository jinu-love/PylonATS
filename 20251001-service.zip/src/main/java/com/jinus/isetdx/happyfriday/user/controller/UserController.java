package com.jinus.isetdx.happyfriday.user.controller;

import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping(path = "/v1")
public interface UserController {

	static final String RESOURCE = "/user";
}
