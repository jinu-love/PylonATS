package com.jinus.isetdx.happyfriday.overtime.service.get_select_overtime_status;

import lombok.Data;

@Data
public class GetSelectOvertimeStatusIn {
	private String name;
	private String radioValue;
}
