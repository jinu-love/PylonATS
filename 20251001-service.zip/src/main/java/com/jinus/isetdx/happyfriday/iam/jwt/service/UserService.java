package com.jinus.isetdx.happyfriday.iam.jwt.service;

import com.jinus.isetdx.happyfriday.iam.jwt.dto.CreateUserRequest;
import com.jinus.isetdx.happyfriday.iam.jwt.dto.UserResponse;

public interface UserService {
    UserResponse createUser(CreateUserRequest request);
}
