package com.jinus.isetdx.happyfriday.overtime.service.get_select_overtime_status;

import lombok.Data;

@Data
public class OvertimeStatus {
	private String name;
	private String dept;
	private String overtimeDate;
	private String overtimeHours;
	private String changedDate;
	private String dayOffDate;
	private String comment;
}
