package com.jinus.isetdx.happyfriday.overtime.service.save_day_off;

import java.time.DayOfWeek;
import java.time.ZonedDateTime;

import com.jinus.dbist.dml.Query;
import com.jinus.framework.exception.BizException;
import com.jinus.framework.util.DbUtils;
import com.jinus.framework.util.ValueUtils;
import com.jinus.isetdx.happyfriday.model.DayOffInf;
import com.jinus.isetdx.happyfriday.model.OvertimeInf;

public class SaveDayOff {
	
	public SaveDayOffOut saveDayOff(SaveDayOffIn input) throws Exception {
		
		if(ValueUtils.isEmpty(input.getDayOffDate())) {
			throw new BizException("ERR-003", "해피휴무 날짜를 입력해주세요.");
		}
		
		
		ZonedDateTime date = ValueUtils.getZonedDateTime();
		
		DayOfWeek dayOfWeek = ValueUtils.toZonedDateTime(input.getDayOffDate()).getDayOfWeek();

		int dayOfWeekNumber = dayOfWeek.getValue();

		if (dayOfWeekNumber >= 6) {
			throw new BizException("ERR-002", "주말에는 해피휴무를 등록할 수 없습니다.");
		}
		
		OvertimeInf overtimeInf = DbUtils.select(OvertimeInf.class,
				DbUtils.toId(input.getEmail(), input.getDayOffDate()));
		
		if (!ValueUtils.isEmpty(overtimeInf)) {
			throw new BizException("ERR-004", "입력한 날짜에 초과근무가 등록되어 있습니다.");
		}
		

		String thisYearMonth = ValueUtils.toDateStr(ValueUtils.getZonedDateTime(), "YYYYMM");
		
		Query query = new Query();
		query.addFilter("email", input.getEmail());
		query.addFilter("dayOffDate", "like", thisYearMonth + "%");
		DbUtils.deleteList(DayOffInf.class, query);
		
		DayOffInf dayOffInf = new DayOffInf();
		dayOffInf.setEmail(input.getEmail());
		dayOffInf.setDayOffDate(input.getDayOffDate());
		dayOffInf.setComment(input.getComment());
		dayOffInf.setCreatedDate(date);
		dayOffInf.setUpdatedDate(date);
		DbUtils.insert(dayOffInf);
		
		SaveDayOffOut output = new SaveDayOffOut();
		output.setSuccess(true);
		return output;
		
	}

}
