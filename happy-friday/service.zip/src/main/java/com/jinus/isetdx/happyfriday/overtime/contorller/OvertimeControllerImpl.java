package com.jinus.isetdx.happyfriday.overtime.contorller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

import com.jinus.framework.util.BeanUtils;
import com.jinus.isetdx.happyfriday.overtime.service.get_overtime_history.GetOvertimeHistory;
import com.jinus.isetdx.happyfriday.overtime.service.get_overtime_history.GetOvertimeHistoryIn;
import com.jinus.isetdx.happyfriday.overtime.service.get_overtime_history.GetOvertimeHistoryOut;
import com.jinus.isetdx.happyfriday.overtime.service.get_this_month_overtime.GetThisMonthOvertime;
import com.jinus.isetdx.happyfriday.overtime.service.get_this_month_overtime.GetThisMonthOvertimeIn;
import com.jinus.isetdx.happyfriday.overtime.service.get_this_month_overtime.GetThisMonthOvertimeOut;
import com.jinus.isetdx.happyfriday.overtime.service.save_day_off.SaveDayOff;
import com.jinus.isetdx.happyfriday.overtime.service.save_day_off.SaveDayOffIn;
import com.jinus.isetdx.happyfriday.overtime.service.save_day_off.SaveDayOffOut;
import com.jinus.isetdx.happyfriday.overtime.service.save_overtime.SaveOvertime;
import com.jinus.isetdx.happyfriday.overtime.service.save_overtime.SaveOvertimeIn;
import com.jinus.isetdx.happyfriday.overtime.service.save_overtime.SaveOvertimeOut;
@CrossOrigin
@RestController
public class OvertimeControllerImpl implements OvertimeController {

	@Override
	public GetOvertimeHistoryOut getOvertimeHistory(GetOvertimeHistoryIn input) throws Exception {
		return BeanUtils.get(GetOvertimeHistory.class).getOvertimeHistory(input);
	}
	
	@Override
	public GetThisMonthOvertimeOut getThisMonthOvertime(GetThisMonthOvertimeIn input) throws Exception {
		return BeanUtils.get(GetThisMonthOvertime.class).getThisMonthOvertime(input);
	}

	@Override
	public SaveOvertimeOut saveOvertime(SaveOvertimeIn input) throws Exception {
		return BeanUtils.get(SaveOvertime.class).saveOvertime(input);
	}

	@Override
	public SaveDayOffOut saveDayOff(SaveDayOffIn input) throws Exception {
		return BeanUtils.get(SaveDayOff.class).saveDayOff(input);
	}

}
