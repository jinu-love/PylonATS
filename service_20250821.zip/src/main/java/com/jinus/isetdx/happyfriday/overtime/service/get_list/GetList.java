package com.jinus.isetdx.happyfriday.overtime.service.get_list;

public class GetList {

	public GetListOut getList(GetListIn input) throws Exception {

		GetListOut output = new GetListOut();
		output.setSuccess(true);
		return output;
	}

}