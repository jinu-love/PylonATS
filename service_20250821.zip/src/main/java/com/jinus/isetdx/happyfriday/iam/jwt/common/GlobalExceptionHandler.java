package com.jinus.isetdx.happyfriday.iam.jwt.common;

import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;

public class GlobalExceptionHandler {
	@ExceptionHandler(IllegalArgumentException.class)
	public ResponseEntity<?> handleIllegalArgument(IllegalArgumentException e) {
		return ResponseEntity.badRequest().body(Map.of("message", e.getMessage()));
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<?> handleValidation(MethodArgumentNotValidException e) {
		String msg = e.getBindingResult().getFieldErrors().stream().findFirst()
				.map(err -> err.getField() + " " + err.getDefaultMessage()).orElse("유효성 검증 실패");
		return ResponseEntity.badRequest().body(Map.of("message", msg));
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<?> handleOther(Exception e) {
		return ResponseEntity.internalServerError().body(Map.of("message", "서버 오류가 발생했습니다."));
	}
}
