package com.jinus.isetdx.happyfriday.overtime.service.get;

public class Get {

	public GetOut get(GetIn input) throws Exception {

		GetOut output = new GetOut();
		output.setSuccess(true);
		return output;
	}

}
