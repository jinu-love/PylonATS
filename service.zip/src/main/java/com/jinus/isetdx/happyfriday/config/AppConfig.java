package com.jinus.isetdx.happyfriday.config;


import java.time.format.DateTimeFormatter;
import java.util.TimeZone;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.jinus.framework.config.properties.EntryProperties;
import com.jinus.framework.config.properties.ErrorProperties;
import com.jinus.framework.config.properties.FileServiceProperties;
import com.jinus.framework.config.properties.MsaProperties;
import com.jinus.framework.config.properties.ServiceProperties;
import com.jinus.framework.util.BeanUtils;




@Configuration
@EnableConfigurationProperties({ ServiceProperties.class, MsaProperties.class, EntryProperties.class,
				ErrorProperties.class, SecurityProperties.class,
				FileServiceProperties.class })
public class AppConfig {
	
	private static final String dateFormat = "yyyy-MM-dd";
    private static final String datetimeFormat = "yyyy-MM-dd'T'HH:mm:ssZ";

    //Parameter 0 of method setCacheManager 에러 발생해서 주석 처리함
//  @Autowired
//	public void setCacheManager(CacheManager cacheManager) {
//		CacheUtils.setCacheManager(cacheManager);
//	}
    
    @Value("${server.timezone:Asia/Seoul}")
    private String timezone;
    
    @Bean
    public Jackson2ObjectMapperBuilderCustomizer jackson2ObjectMapperBuilderCustomizer() {
        
        TimeZone.setDefault(TimeZone.getTimeZone(timezone));
        
        return jacksonObjectMapperBuilder -> {
            jacksonObjectMapperBuilder.timeZone(TimeZone.getDefault());
            jacksonObjectMapperBuilder.simpleDateFormat(datetimeFormat);
            jacksonObjectMapperBuilder.serializers(new LocalDateSerializer(DateTimeFormatter.ofPattern(dateFormat)));
            jacksonObjectMapperBuilder.serializers(new LocalDateTimeSerializer(DateTimeFormatter.ofPattern(datetimeFormat)));
        };
    }
    
    @Bean
	public BeanUtils beanUtils() {
		return new BeanUtils();
	}

    //이게 있으면 필터를 수행하는것 같아서 일단 주석 처리해보고 진행해보자
//	@Bean
//	public FilterRegistrationBean<EntryFilter> entryFilter() {
//		EntryFilter entryFilter = new EntryFilter();
//		FilterRegistrationBean<EntryFilter> bean = new FilterRegistrationBean<EntryFilter>(entryFilter);
//		bean.addUrlPatterns("/*");
//		bean.setOrder(1);
//		return bean;
//	}

	@Bean
	ModelMapper modelMapper() {
		return new ModelMapper();
	}
	
//	@Bean
//	PasswordEncoder passwordEncoder() {
//		return new BCryptPasswordEncoder();
//	}
}
