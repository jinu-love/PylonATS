package com.jinus.isetdx.happyfriday.iam.jwt.controller;



import com.jinus.isetdx.happyfriday.iam.jwt.dto.LoginDto;
import com.jinus.isetdx.happyfriday.iam.jwt.dto.TokenDto;
import com.jinus.isetdx.happyfriday.iam.jwt.util.JwtUtil;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
public class AuthController {
    
    private final JwtUtil jwtUtil;
    private final AuthenticationManager authenticationManager;
    
    @PostMapping("/authenticate")
    public ResponseEntity<?> authenticate(@RequestBody @Valid LoginDto loginDto) {
        try {
            UsernamePasswordAuthenticationToken authenticationToken =
                    new UsernamePasswordAuthenticationToken(loginDto.getEmail(), loginDto.getPassword());
            
            Authentication authentication = authenticationManager.authenticate(authenticationToken);
            
            String jwt = jwtUtil.createToken(authentication);
            
            return ResponseEntity.ok(new TokenDto(jwt, "Bearer", loginDto.getEmail()));
        } catch (AuthenticationException e) {
            return ResponseEntity.status(401).body("인증에 실패했습니다.");
        }
    }
    
    @GetMapping("/user")
    public ResponseEntity<String> getMyUserInfo(Authentication authentication) {
        return ResponseEntity.ok("안녕하세요, " + authentication.getName() + "님!");
    }
}

