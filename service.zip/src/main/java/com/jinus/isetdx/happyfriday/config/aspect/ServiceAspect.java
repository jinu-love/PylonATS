package com.jinus.isetdx.happyfriday.config.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import com.jinus.dbist.dml.Dml;
import com.jinus.framework.util.DbUtils;
import com.zaxxer.hikari.HikariDataSource;

@Aspect
@Component
public class ServiceAspect extends com.jinus.framework.aspect.ServiceAspect {
	@Around("execution(* com.jinu.pylon.mvs.biz.mes.lot.resource.service.*.*.*(..))"
			+ " or execution(* com.jinu.pylon.mvs.biz.mes.mat.resource.service.*.*.*(..))")
	public Object doAround(ProceedingJoinPoint pjp) throws Throwable {

		Dml dml = DbUtils.getDml();
		HikariDataSource hds = (HikariDataSource) dml.getDataSource();
		System.out.println(hds.getPoolName());

		
		return super.doAround(pjp);
	}

}
