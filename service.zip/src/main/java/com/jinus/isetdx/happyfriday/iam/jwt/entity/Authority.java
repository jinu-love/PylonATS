package com.jinus.isetdx.happyfriday.iam.jwt.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "authority")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Authority {
    
    @Id
    @Column(name = "authority_name", length = 50)
    private String authorityName;
}

