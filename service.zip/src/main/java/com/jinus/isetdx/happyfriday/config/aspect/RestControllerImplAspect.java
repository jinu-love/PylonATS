package com.jinus.isetdx.happyfriday.config.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class RestControllerImplAspect extends com.jinus.framework.aspect.RestControllerImplAspect{
	
	@Around("execution(* com.jinu.pylon.mvs.biz.mes.lot.resource.controller.*Impl.*(..))"
			+ " or execution(* com.jinu.pylon.mvs.biz.mes.mat.resource.controller.*Impl.*(..))")
	public Object doAround(ProceedingJoinPoint pjp) throws Throwable {
		return super.doAround(pjp);
	}

}
